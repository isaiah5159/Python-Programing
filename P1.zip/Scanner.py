from string import ascii_letters, digits, whitespace
from Core import Core

class Scanner:

    # Constructor should open the file and find the first token
    def __init__(self, filename):
        # Open the file and grab current position. 
        self.text = open(filename, 'r')
        self.current = self.text.tell()
        # Variables that can be used later and then go to next.
        self.previous = None
        self.id = None
        self.token = None
        self.constant = None
        self.nextToken()
	
	# Making sure it is at starting position
    def reset(self):
        self.text.seek(0)
	
	# Reading in one character
    def readChar(self):
        char = self.text.read(1)
        self.previous = self.current
        self.current = self.text.tell()
        return char
	
	# Moving to the next character
    def nextChar(self):
        self.text.seek(self.previous)
        self.current = self.previous
        self.previous = None

	# Handling the error message
    def errrorMessage(self, problem):
        print("ERROR: Invalid character or constant: " + problem)
        self.token = Core.ERROR


    # nextToken should advance the scanner to the next token
    def nextToken(self):

        ch = self.readChar()
        
        # Skip all whitespaces
        while ch in whitespace and ch != "":
            ch = self.readChar()

        # Handle the end of the stream, along with all of the cores
        if ch == "":
            self.token = Core.EOF
            
        elif ch in ascii_letters:
            tString = ""
            
            while (ch in ascii_letters or ch in digits) and ch != "":
                tString += ch               
                ch = self.readChar()               
            self.nextChar()
            
            if tString == "program":
                self.token = Core.PROGRAM
                
            elif tString == "begin":
                self.token = Core.BEGIN
                
            elif tString == "end":
                self.token = Core.END
                
            elif tString == "new":
                self.token = Core.NEW
                
            elif tString == "define":
                self.token = Core.DEFINE
                
            elif tString == "extends":
                self.token = Core.EXTENDS
                
            elif tString == "class":
                self.token = Core.CLASS
                
            elif tString == "endclass":
                self.token = Core.ENDCLASS
                
            elif tString == "int":
                self.token = Core.INT
                
            elif tString == "endfunc":
                self.token = Core.ENDFUNC
                
            elif tString == "if":
                self.token = Core.IF
                
            elif tString == "then":
                self.token = Core.THEN
                
            elif tString == "else":
                self.token = Core.ELSE
                
            elif tString == "while":
                self.token = Core.WHILE
                
            elif tString == "endwhile":
                self.token = Core.ENDWHILE
                
            elif tString == "endif":
                self.token = Core.ENDIF
                                    	
            elif tString == "input":
                self.token = Core.INPUT
                
            elif tString == "output":
                self.token = Core.OUTPUT
                
            else:
                self.token = Core.ID               
                self.id = tString
                
        elif ch in digits:
            tString = ""
            
            while ch in digits and ch != "":
                tString += ch
                ch = self.readChar()
            self.nextChar()
            self.constant = int(tString)
            self.token = Core.CONST
            
            if self.constant > 1023:
                self.errrorMessage(tString)
                
        elif ch == ';':
            self.token = Core.SEMICOLON
            
        elif ch == '(':
            self.token = Core.LPAREN
            
        elif ch == ')':
            self.token = Core.RPAREN
            
        elif ch == ',':
            self.token = Core.COMMA
            
        elif ch == '!':
            self.token = Core.NEGATION
            
        elif ch == '+':
            self.token = Core.ADD
            
        elif ch == '-':
            self.token = Core.SUB
            
        elif ch == '*':
            self.token = Core.MULT
            
        elif ch == '=':
            nextChar = self.readChar()
            
            if nextChar == '=':
                self.token = Core.EQUAL
                
            else:
                self.nextChar()
                self.token = Core.ASSIGN
                
        elif ch == '<':
            nextChar = self.readChar()
            
            if nextChar == '=':
                self.token = Core.LESSEQUAL
                
            else:
                self.nextChar()
                self.token = Core.LESS                
                                          
        else:
            self.errrorMessage(ch)

    # currentToken should return the current token
    def currentToken(self):
        return self.token

  # If the current token is ID, return the string value of the identifier
    # Otherwise, return value does not matter
    def getID(self):
        return self.id

  # If the current token is CONST, return the numerical value of the constant
	# Otherwise, return value does not matter
    def getCONST(self):
        return self.constant


