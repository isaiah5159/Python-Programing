Isaiah Green


– The names of all files you are submitting and a brief description stating what each file contains

I will be sumbmiting the python files. Which is the Main.py, core.py, and Scanner.py. Also am i supposed to submit the other files if I did nothing to them?
I have only made changes to the scanner and no other file. What the Scanner does is read through the file to output tokens as it sees them and no matter the order they come in.

– Any special features or comments on your project

I did use an import to help with the cases. That way I could shorten up my code and it made it easier to handle.

– Any known bugs in your scanner

The only bug in my scanner is that i could not get the ref to work. For some reason i could not wrap my brain around it to get it done and working but other than that everything else works.
