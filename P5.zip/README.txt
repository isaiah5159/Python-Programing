Isaiah Green 

– The names of all the other files you are submitting and a brief description of each
stating what the file contains
Assign.java Cmpr.java Cond.java Core.java Decl.java DeclClass.java DeclInt.java DeclSeq.java Executor.java Expr.java Factor.java
Formals.java FuncCall.java FuncDecl.java GarbageCollector.java Id.java IdList.java If.java In.java Loop.java Main.java Out.java
Parser.java Program.java Scanner.java Stmt.java StmtSeq.java Term.java README.txt

– Any special features or comments on your project
I tried to redo the projects and came up with this kind of implementationto get a better understanding and switched to java.

– A description of the overall design of the interpreter, in particular how the call
stack is implemented.
Eveything is organized as a stack there is a that caller pushes the return address onto the stack and i tried to make it 
where the stack pulls or pops the return address off the call stack and transfers control to that address. 

– A brief description of how you tested the interpreter and a list of known remaining
bugs (if any)
I can not get my implementation to work for this project at all Or im running it incorrectly to test.
which i dont think i am because have tried java Main.java Correct/0.code or java Main.java Correct/0.code Correct/0.data